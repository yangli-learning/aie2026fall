"""Readable helpers for AIE1901 Lab 3.

Student workflow: load data -> make model -> choose trainable layers ->
train -> evaluate. Only train and test splits are used in this lab.
The test set monitors learning and selects the saved epoch.
"""

import copy
import hashlib
import json
import random
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from PIL import Image, ImageEnhance, ImageOps
# torch handles tensors; nn provides layers such as Linear and loss functions.
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms


# ---------------------------------------------------------------------------
# 1. Reproducibility and image data
# ---------------------------------------------------------------------------

def set_seed(seed=42):
    """Use the same random choices when an experiment is repeated."""
    # Different libraries have separate random generators, so seed each one.
    # This controls choices such as image sampling and initial model weights.
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def get_device():
    """Use a local CUDA GPU when available; otherwise use CPU."""
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def save_json(value, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2), encoding="utf-8")


def scan_images(root):
    """Read class folders; remove decoded duplicates and conflicting labels.

    Returns (records, class_names, audit). A record stores path, integer label,
    and a hash of the decoded RGB pixels. Original files are never modified.
    Images with the same pixels but different labels are ALL excluded.
    """
    root = Path(root).resolve()
    if not root.is_dir():
        raise FileNotFoundError(f"Image folder not found: {root}")
    # Alphabetical folder order gives a consistent mapping: class name -> 0, 1, 2.
    # Each task must pass class names that match its own record labels.
    class_names = sorted(p.name for p in root.iterdir()
                         if p.is_dir() and not p.name.startswith("."))
    if len(class_names) < 2:
        raise ValueError("Use at least two class folders directly inside the data folder.")
    extensions = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}
    grouped = {}
    audit = {"duplicates": [], "conflicting_labels": [], "unreadable": []}
    for label, name in enumerate(class_names):
        for path in sorted((root / name).rglob("*")):
            if path.suffix.lower() not in extensions:
                continue
            try:
                with Image.open(path) as image:
                    # Respect the camera's orientation and use three colour channels.
                    image = ImageOps.exif_transpose(image).convert("RGB")
                    content = str(image.size).encode() + image.tobytes()
                    # A hash acts as an image fingerprint, independent of its filename.
                    fingerprint = hashlib.sha256(content).hexdigest()
            except (OSError, ValueError) as error:
                audit["unreadable"].append({"path": str(path), "reason": str(error)})
                continue
            record = {"path": str(path), "label": label, "hash": fingerprint}
            grouped.setdefault(fingerprint, []).append(record)

    # Keep one copy when labels agree; exclude all copies when labels conflict.
    records = []
    for copies in grouped.values():
        if len({item["label"] for item in copies}) > 1:
            audit["conflicting_labels"].append([item["path"] for item in copies])
        else:
            records.append(copies[0])
            audit["duplicates"].extend(item["path"] for item in copies[1:])
    records.sort(key=lambda item: item["path"])
    counts = [sum(item["label"] == i for item in records) for i in range(len(class_names))]
    if min(counts) == 0:
        raise ValueError("Each class must have at least one valid, uniquely labelled image.")
    print(f"{root.name}: {dict(zip(class_names, counts))}")
    print(f"Excluded {len(audit['duplicates'])} duplicate copies, "
          f"{sum(map(len, audit['conflicting_labels']))} conflicting files, "
          f"{len(audit['unreadable'])} unreadable files.")
    return records, class_names, audit


def balanced_split(records, sizes, num_classes, seed=42):
    """Disjoint splits with exactly sizes[name] images per class.

    Extra images are unused. The saved manifest explains every selection.
    """
    if any(not isinstance(n, int) or n < 1 for n in sizes.values()):
        raise ValueError("Every split size must be a positive integer per class.")
    # A local generator repeats this shuffle without changing other random choices.
    rng = random.Random(seed)
    splits = {name: [] for name in sizes}
    for label in range(num_classes):
        # Split one class at a time so each split has equal numbers per class.
        pool = [item for item in records if item["label"] == label]
        rng.shuffle(pool)
        if len(pool) < sum(sizes.values()):
            raise ValueError(f"Class {label}: need {sum(sizes.values())} unique images, "
                             f"but only {len(pool)} are available.")
        start = 0
        for name, count in sizes.items():
            # Take the next unused slice; advancing start prevents split overlap.
            splits[name].extend(pool[start:start + count])
            start += count
    return splits


def select_classes(records, original_names, selected_names):
    """Keep selected physical classes and give them consecutive task labels.

    For selected_names=["Ripe", "Green"], Ripe becomes 0 and Green becomes 1.
    This selects real images; it never changes a banana's physical class.
    Original records are copied, so another task can safely reuse the pool.
    """
    if not selected_names or len(set(selected_names)) != len(selected_names):
        raise ValueError("Select distinct, non-empty class names.")
    if not set(selected_names) <= set(original_names):
        raise ValueError("A selected class is not present in the original dataset.")
    selected = []
    for record in records:
        name = original_names[record["label"]]
        if name in selected_names:
            selected.append({**record, "label": selected_names.index(name)})
    return selected


def prepare_provided_data(data_root, output_dir="outputs", seed=42):
    """Prepare binary source/natural tasks and a three-class controlled pool.

    Each role stores its OWN class_names together with train/test records.
    Green is reserved for the controlled pool and never enters source training
    or testing. All six image sets are disjoint; test images stay fixed.
    """
    source, names, source_audit = scan_images(Path(data_root) / "DataBanana2")
    target, target_names, target_audit = scan_images(Path(data_root) / "DataBanana1")
    if names != target_names:
        raise ValueError("Source and target class folder names must match exactly.")
    # Target images must not be identical to images in the source pool.
    source_hashes = {item["hash"] for item in source}
    overlap = [item["path"] for item in target if item["hash"] in source_hashes]
    target = [item for item in target if item["hash"] not in source_hashes]
    # Dataset contents and task classes are different concepts. Steps 1, 2 and 3
    # use only these two classes, in this explicit order (not folder order).
    task_names = ["Ripe", "Overripe"]
    source_binary = select_classes(source, names, task_names)
    target_binary = select_classes(target, names, task_names)
    source_splits = balanced_split(source_binary, {
        "source_train": 120, "source_test": 40,
        "control_train": 20, "control_test": 15,
    }, len(task_names), seed)
    target_splits = balanced_split(target_binary, {"train": 25, "test": 16},
                                   len(task_names), seed + 1)
    # Green has a separate reservation; none of its images become source data.
    green = select_classes(source, names, ["Green"])
    green_splits = balanced_split(green, {"train": 20, "test": 15}, 1, seed + 2)
    controlled = {"class_names": task_names + ["Green"]}
    for split in ["train", "test"]:
        # Ripe/Overripe labels are 0/1; Green is label 2 in this reserved pool.
        controlled[split] = source_splits[f"control_{split}"] + [
            {**record, "label": 2} for record in green_splits[split]]
    data = {"schema_version": 2, "seed": seed, "dataset_classes": names,
            "source": {"class_names": task_names,
                       "train": source_splits["source_train"],
                       "test": source_splits["source_test"]},
            "natural_target": {"class_names": task_names, **target_splits},
            "controlled_target": controlled,
            "audit": {"source": source_audit, "target": target_audit,
                      "cross_domain_duplicates_excluded": overlap}}
    save_json(data, Path(output_dir) / "provided_manifest.json")
    return data


def prepare_own_data(root, output_dir="outputs/project", seed=42):
    """Read manually separated train/test class folders and check overlap.

    Use separate collection sessions/objects/participants where possible.
    Exact duplicate checks cannot detect every similar video frame.
    """
    splits, audits, seen, class_names = {}, {}, {}, None
    # These two folders have already been separated by the students.
    # seen tracks images across both folders, detecting exact data overlap.
    for split in ["train", "test"]:
        records, names, audit = scan_images(Path(root) / split)
        if class_names is None:
            class_names = names
        elif names != class_names:
            raise ValueError("train and test must contain the same class folders.")
        for item in records:
            if item["hash"] in seen:
                raise ValueError(f"Data leakage across splits: {item['path']} and "
                                 f"{seen[item['hash']]}. Remove one and resplit.")
            seen[item["hash"]] = item["path"]
        splits[split], audits[split] = records, audit
    save_json({"seed": seed, "class_names": class_names,
               "splits": splits, "audit": audits}, Path(output_dir) / "project_manifest.json")
    return splits, class_names


def sample_per_class(records, n, num_classes, seed=42):
    """Nested samples: for a fixed seed, n=5 is a subset of n=10.

    n=1 means ONE IMAGE PER CLASS, not one image in the entire training set.
    """
    return balanced_split(records, {"sample": n}, num_classes, seed)["sample"]


def prepare_transfer_data(source_root, target_root, output_dir="outputs/part2",
                          min_train=100, min_test=20):
    """Read student-designed source/target tasks with four disjoint sets.

    Each root contains train/<classes> and test/<classes>. Class lists may
    differ, e.g. two source classes and three target classes. The 100/20
    requirement concerns the TOTAL available train/test images per class
    across the project; students allocate these to source and target roles.
    This does not require 100+100 new training images for a shared class.
    """
    output_dir = Path(output_dir)
    data, seen = {}, {}
    counts = {}
    for role, root in [("source", source_root), ("target", target_root)]:
        splits, names = prepare_own_data(root, output_dir / f"{role}_data")
        data[role] = {"class_names": names, **splits}
        for split, records in splits.items():
            for record in records:
                if record["hash"] in seen:
                    raise ValueError(f"Source/target leakage: {record['path']} and "
                                     f"{seen[record['hash']]}. Use disjoint image files.")
                seen[record["hash"]] = record["path"]
                name = names[record["label"]]
                counts.setdefault(name, {"train": 0, "test": 0})[split] += 1
    for name, values in counts.items():
        if values["train"] < min_train or values["test"] < min_test:
            raise ValueError(f"Class {name}: combined project needs at least "
                             f"{min_train} train and {min_test} test images; got {values}.")
    data["available_per_class"] = counts
    save_json(data, output_dir / "transfer_manifest.json")
    return data


def apply_visual_shift(image, visual_shift=False):
    """Apply a fixed appearance change without changing the physical label.

    False/None: original image. True: the earlier brightness-only example.
    A dictionary specifies brightness, contrast and RGB channel gains.
    The same settings apply to target training AND target test images.
    """
    if visual_shift is None or visual_shift is False:
        return image
    if visual_shift is True:
        return ImageEnhance.Brightness(image).enhance(0.55)
    if not isinstance(visual_shift, dict):
        raise ValueError("visual_shift must be False, True, or an image-settings dictionary.")
    brightness = visual_shift.get("brightness", 1.0)
    contrast = visual_shift.get("contrast", 1.0)
    gains = np.asarray(visual_shift.get("rgb_gain", [1.0, 1.0, 1.0]), dtype=np.float32)
    if (brightness <= 0 or contrast <= 0 or gains.shape != (3,)
            or not np.isfinite(gains).all() or np.any(gains <= 0)):
        raise ValueError("Use positive brightness, contrast and three positive RGB gains.")
    image = ImageEnhance.Brightness(image).enhance(brightness)
    image = ImageEnhance.Contrast(image).enhance(contrast)
    # Red, green and blue gains simulate a fixed camera colour response.
    pixels = np.asarray(image, dtype=np.float32) * gains
    return Image.fromarray(np.clip(pixels, 0, 255).astype(np.uint8))


class ImageDataset(Dataset):
    """A list of image paths + labels, with optional controlled changes."""

    def __init__(self, records, transform, class_names, visual_shift=False):
        self.records = list(records)
        self.transform = transform
        self.class_names = list(class_names)
        self.visual_shift = visual_shift
        # Preprocessing is deterministic, so reusing a tensor saves image I/O.
        # Each loader has its own cache; changed conditions cannot share tensors.
        self.cache = {}
        if any(r["label"] not in range(len(class_names)) for r in self.records):
            raise ValueError("A record label is outside this task's class list.")

    # DataLoader calls __len__ to find the dataset size, and __getitem__ to read
    # one (image tensor, integer label) pair. Students call make_loader instead.
    def __len__(self):
        return len(self.records)

    def __getitem__(self, index):
        if index in self.cache:
            return self.cache[index]
        record = self.records[index]
        with Image.open(record["path"]) as image:
            image = ImageOps.exif_transpose(image).convert("RGB")
        # Use the same fixed camera settings as the image previews.
        image = apply_visual_shift(image, self.visual_shift)
        # Labels already describe the selected physical classes for this task.
        label = record["label"]
        self.cache[index] = (self.transform(image), label)
        return self.cache[index]


def make_transform():
    """Use the same deterministic 64x64 RGB input in both parts.

    SimpleMLP averages this input to a smaller grid before its linear layers.
    No pretrained weights, network download or data augmentation is needed.
    """
    return transforms.Compose([transforms.Resize((64, 64)), transforms.ToTensor()])


def make_loader(records, class_names, transform=None, batch_size=16,
                shuffle=False, seed=42, visual_shift=False):
    if not records:
        raise ValueError("An empty dataset cannot be trained or evaluated.")
    if batch_size < 1:
        raise ValueError("batch_size must be positive.")
    if transform is None:
        transform = make_transform()
    dataset = ImageDataset(records, transform, class_names, visual_shift)
    # DataLoader stacks images into [batch_size, 3, height, width].
    # Shuffle training data; keep evaluation order fixed to match file paths.
    generator = torch.Generator().manual_seed(seed)
    return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle,
                      generator=generator, num_workers=0)


def show_samples(records, class_names, visual_shift=False, count=6, save_path=None):
    """Show the selected physical classes before training."""
    chosen = []
    for label in range(len(class_names)):
        chosen.extend([r for r in records if r["label"] == label][:max(1, count // len(class_names))])
    chosen = chosen[:count]
    fig, axes = plt.subplots(1, len(chosen), figsize=(3 * len(chosen), 3), squeeze=False)
    for ax, record in zip(axes[0], chosen):
        with Image.open(record["path"]) as image:
            image = ImageOps.exif_transpose(image).convert("RGB")
        image = apply_visual_shift(image, visual_shift)
        ax.imshow(image)
        ax.set_title(class_names[record["label"]])
        ax.axis("off")
    fig.tight_layout()
    if save_path:
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=160, bbox_inches="tight")
    plt.show()
    # Do not return fig: a notebook would display that returned figure again.
    plt.close(fig)


# ---------------------------------------------------------------------------
# 2. Models and freezing
# ---------------------------------------------------------------------------

MLP_PRESETS = {
    "small": (16, 16, 16),
    "medium": (32, 32, 32),
    "large": (64, 64, 32),
}


class SimpleMLP(nn.Module):
    """RGB image -> average pooling -> flatten -> hidden blocks -> head.

    The default 16x16 grid reduces input features from 12288 to 768.
    Each hidden block is Linear + ReLU + optional Dropout. The head gives
    one raw score per class; CrossEntropyLoss handles log-softmax itself.
    Students may edit hidden_dims, pooled_size and dropout in Part 2.
    """

    def __init__(self, num_classes=2, hidden_dims=(32, 32, 32),
                 pooled_size=16, dropout=0.2):
        super().__init__()
        if not hidden_dims or any(not isinstance(n, int) or n < 1 for n in hidden_dims):
            raise ValueError("hidden_dims must contain positive integer widths.")
        if not isinstance(pooled_size, int) or not 1 <= pooled_size <= 64:
            raise ValueError("pooled_size must be an integer from 1 to 64.")
        if not 0 <= dropout < 1:
            raise ValueError("dropout must be in [0, 1).")
        # Averaging neighbouring pixels gives fewer inputs to the first Linear.
        self.pool = nn.AdaptiveAvgPool2d((pooled_size, pooled_size))
        self.flatten = nn.Flatten()
        self.blocks = nn.ModuleList()
        input_dim = 3 * pooled_size * pooled_size
        for width in hidden_dims:
            # Linear learns weighted features; ReLU replaces negative values by 0.
            layers = [nn.Linear(input_dim, width), nn.ReLU()]
            if dropout > 0:
                # Dropout randomly hides some features during training only.
                layers.append(nn.Dropout(dropout))
            self.blocks.append(nn.Sequential(*layers))
            input_dim = width
        self.head = nn.Linear(input_dim, num_classes)
        # Save the architecture as plain values so checkpoints can be rebuilt.
        self.config = {"kind": "mlp", "num_classes": num_classes,
                       "hidden_dims": list(hidden_dims), "pooled_size": pooled_size,
                       "dropout": dropout}

    def forward(self, images):
        # PyTorch calls forward automatically when we write model(images).
        features = self.flatten(self.pool(images))
        for block in self.blocks:
            features = block(features)
        return self.head(features)


def make_model(kind="mlp", num_classes=2, size="medium", hidden_dims=None,
               pooled_size=16, dropout=0.1, seed=42):
    """Make a randomly initialized MLP; source knowledge comes from training.

    size selects a starter. An explicit hidden_dims list overrides that size.
    Part 1 uses fixed settings; Part 2 allows students to modify the model.
    """
    if kind != "mlp":
        raise ValueError("This lab uses kind='mlp' only.")
    if hidden_dims is None:
        if size not in MLP_PRESETS:
            raise ValueError("size must be 'small', 'medium', or 'large'.")
        hidden_dims = MLP_PRESETS[size]
    set_seed(seed)
    return SimpleMLP(num_classes, hidden_dims, pooled_size, dropout)


def adapt_model(source_model, strategy="full", freeze_layers=0, seed=42):
    """Create an independent copy: every run starts from the SAME source.

    full: update all layers; freeze: freeze the FIRST freeze_layers hidden
    layers, updating later layers and the existing head; retrain_head:
    freeze all hidden layers, reset the head, and train only that new head.
    """
    if not isinstance(source_model, SimpleMLP):
        raise TypeError("adapt_model expects a SimpleMLP source model.")
    if strategy not in ("full", "freeze", "retrain_head"):
        raise ValueError("strategy must be 'full', 'freeze', or 'retrain_head'.")
    if strategy == "freeze" and freeze_layers not in range(len(source_model.blocks) + 1):
        raise ValueError(f"freeze_layers must be 0..{len(source_model.blocks)}.")
    # model = source_model would refer to the SAME object. deepcopy makes a new
    # model, so adapting this run cannot change the next run's starting weights.
    model = copy.deepcopy(source_model).cpu()
    for index, block in enumerate(model.blocks):
        # Python indices start at 0: freeze_layers=2 freezes indices 0 and 1.
        # requires_grad=True allows this layer's weights to update during training.
        update = strategy == "full" or (strategy == "freeze" and index >= freeze_layers)
        for parameter in block.parameters():
            parameter.requires_grad = update
    if strategy == "retrain_head":
        set_seed(seed)
        # Forget the source head's weights, keeping the learned hidden features.
        model.head.reset_parameters()
    # The head always trains. Only retrain_head replaces its starting weights.
    for parameter in model.head.parameters():
        parameter.requires_grad = True
    return model


def replace_head(model, num_classes, seed=42):
    """Give an independent MLP a new head for its target task; return that MLP.

    Call this AFTER copying the source. The same seed gives identical new
    heads for full tuning, head-only training and the no-transfer baseline.
    Two outputs can have different meanings: Ripe/Overripe versus Ripe/Green.
    """
    if not isinstance(model, SimpleMLP):
        raise TypeError("replace_head expects a SimpleMLP.")
    set_seed(seed)
    model.head = nn.Linear(model.head.in_features, num_classes)
    model.config["num_classes"] = num_classes
    return model



def describe_model(model):
    """A small table makes the train/freeze decision visible."""
    rows = []
    for name, block in [(f"Block {i + 1}", b) for i, b in enumerate(model.blocks)] + [("Head", model.head)]:
        rows.append({"module": name,
                     "parameters": sum(p.numel() for p in block.parameters()),
                     "trainable": sum(p.numel() for p in block.parameters() if p.requires_grad)})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# 3. Training and evaluation (test data monitors learning and selects the epoch)
# ---------------------------------------------------------------------------

def _training_mode(model):
    # train()/eval() set Dropout behaviour; they do not update weights themselves.
    model.train()
    # Frozen hidden layers keep dropout OFF so their feature mapping stays fixed.
    for block in model.blocks:
        if not any(p.requires_grad for p in block.parameters()):
            block.eval()


# Evaluation needs predictions only; skipping gradients reduces memory usage.
@torch.no_grad()
def evaluate(model, loader, device=None):
    """Accuracy, balanced accuracy, confusion matrix, and all predictions."""
    device = get_device() if device is None else torch.device(device)
    # The model and its input tensors must be on the same CPU/GPU device.
    # eval() also switches dropout off for deterministic predictions.
    model.to(device).eval()
    loss_fn = nn.CrossEntropyLoss()
    total_loss, true, predicted, confidence = 0.0, [], [], []
    for images, labels in loader:
        images, labels = images.to(device), labels.to(device)
        scores = model(images)
        total_loss += loss_fn(scores, labels).item() * len(labels)
        # scores has shape [batch, classes]. Softmax converts each row to
        # probabilities that sum to 1; dim=1 means the class dimension.
        probabilities = scores.softmax(dim=1)
        best_confidence, best_class = probabilities.max(dim=1)
        true.extend(labels.cpu().tolist())
        predicted.extend(best_class.cpu().tolist())
        confidence.extend(best_confidence.cpu().tolist())
    num_classes = len(loader.dataset.class_names)
    # Rows = true classes, columns = predictions; diagonal entries are correct.
    confusion = np.zeros((num_classes, num_classes), dtype=int)
    for actual, guess in zip(true, predicted):
        confusion[actual, guess] += 1
    counts = confusion.sum(axis=1)
    # Per-class accuracy = correct images in that class / all images in that class.
    # Balanced accuracy gives each class equal weight, regardless of sample count.
    recalls = np.divide(confusion.diagonal(), counts,
                        out=np.full(num_classes, np.nan), where=counts > 0)
    return {"loss": total_loss / len(true),
            "accuracy": float(np.mean(np.array(true) == np.array(predicted))),
            "balanced_accuracy": float(np.nanmean(recalls)),
            "per_class_accuracy": recalls.tolist(), "confusion": confusion.tolist(),
            "n": len(true), "true": true, "predicted": predicted,
            "confidence": confidence}


def train(model, train_loader, test_loader, epochs=30, learning_rate=0.001,
          device=None, seed=42, verbose=True, weight_decay=0.001):
    """Train on train_loader and monitor test_loader after each epoch.

    model is updated in place. Return the learning curves and elapsed seconds.
    The lowest test loss selects the saved epoch. For paired comparisons,
    use newly created loaders with the same seed and a fixed test set.
    """
    if epochs < 1 or learning_rate <= 0 or weight_decay < 0:
        raise ValueError("Use positive epochs/learning_rate and non-negative weight_decay.")
    set_seed(seed)
    device = get_device() if device is None else torch.device(device)
    model.to(device)
    # Give the optimizer only trainable parameters; frozen weights are excluded.
    parameters = [p for p in model.parameters() if p.requires_grad]
    if not parameters:
        raise ValueError("No trainable parameters. Unfreeze a block or head first.")
    # A small weight penalty discourages unnecessarily large learned weights.
    optimizer = torch.optim.Adam(parameters, lr=learning_rate, weight_decay=weight_decay)
    # Cross-entropy expects raw class scores and integer labels, not softmax values.
    loss_fn = nn.CrossEntropyLoss()
    best_loss, best_state, best_epoch = float("inf"), None, None
    history = []
    start = time.perf_counter()
    for epoch in range(1, epochs + 1):
        _training_mode(model)
        for images, labels in train_loader:
            images, labels = images.to(device), labels.to(device)
            # 1. Forward pass: predict a score for each class in this batch.
            scores = model(images)
            # 2. Measure how far those scores are from the true labels.
            loss = loss_fn(scores, labels)
            # 3. Clear the previous batch's gradients (PyTorch accumulates them).
            optimizer.zero_grad()
            # 4. Backpropagation: compute how each trainable parameter affects loss.
            loss.backward()
            # 5. Adam uses those gradients and the learning rate to update weights.
            optimizer.step()
        # Evaluate BOTH curves after the epoch with dropout off. This makes the
        # train/test gap comparable instead of mixing dropout-on/off scores.
        train_result = evaluate(model, train_loader, device)
        # Test images never update weights; test loss selects the saved epoch.
        test_result = evaluate(model, test_loader, device)
        history.append({"epoch": epoch, "train_loss": train_result["loss"],
                        "train_accuracy": train_result["accuracy"],
                        "train_balanced_accuracy": train_result["balanced_accuracy"],
                        "test_loss": test_result["loss"],
                        "test_accuracy": test_result["accuracy"],
                        "test_balanced_accuracy": test_result["balanced_accuracy"]})
        if test_result["loss"] < best_loss:
            best_loss = test_result["loss"]
            # clone() takes a snapshot; a reference would keep changing as we train.
            best_state = {key: value.detach().cpu().clone()
                          for key, value in model.state_dict().items()}
            best_epoch = epoch
        if verbose and (epoch == 1 or epoch % 5 == 0 or epoch == epochs):
            print(f"Epoch {epoch:2d}/{epochs} | train loss {train_result['loss']:.3f} | "
                  f"test loss {test_result['loss']:.3f} | "
                  f"test balanced acc {test_result['balanced_accuracy']:.1%}")
    # Return the lowest-test-loss checkpoint, which may precede the final epoch.
    model.load_state_dict(best_state)
    model.eval()
    return {"history": history, "best_epoch": best_epoch,
            "seconds": time.perf_counter() - start,
            "seed": seed, "epochs": epochs, "learning_rate": learning_rate,
            "weight_decay": weight_decay, "curve_mode": "post_epoch_eval_dropout_off"}


def save_model(model, path, class_names, training=None, extra=None):
    """Save tensors and plain metadata; reload without downloading weights."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    # state_dict contains learned weights and stored layer statistics.
    # config lets load_model rebuild the same architecture before restoring them.
    torch.save({"config": model.config, "class_names": list(class_names),
                "state_dict": {k: v.detach().cpu() for k, v in model.state_dict().items()},
                "training": training, "extra": extra}, path)


def load_model(path, class_names=None):
    checkpoint = torch.load(path, map_location="cpu", weights_only=True)
    if class_names is not None and list(class_names) != checkpoint["class_names"]:
        raise ValueError("Checkpoint class order differs from the dataset.")
    model = make_model(**checkpoint["config"])
    # Creating the architecture alone gives fresh weights; loading restores learning.
    model.load_state_dict(checkpoint["state_dict"])
    model.eval()
    return model


# ---------------------------------------------------------------------------
# 4. Plots and export helpers
# ---------------------------------------------------------------------------

def plot_history(training, save_path=None):
    history = pd.DataFrame(training["history"])
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.5))
    for column, label in [("train_loss", "Train"), ("test_loss", "Test")]:
        axes[0].plot(history.epoch, history[column], label=label)
    for column, label in [("train_balanced_accuracy", "Train"), ("test_balanced_accuracy", "Test")]:
        axes[1].plot(history.epoch, history[column] * 100, label=label)
    for ax, ylabel in zip(axes, ["Cross-entropy loss", "Balanced accuracy (%)"]):
        ax.set_xlabel("Epoch")
        ax.set_ylabel(ylabel)
        ax.axvline(training["best_epoch"], color="grey", linestyle=":", label="Selected epoch")
        ax.legend()
    fig.tight_layout()
    if save_path:
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=160, bbox_inches="tight")
    plt.show()
    # Do not return fig: a notebook would display that returned figure again.
    plt.close(fig)


def plot_comparison(table, label_column, metric="test_balanced_accuracy", save_path=None):
    fig, ax = plt.subplots(figsize=(9, 4))
    ax.bar(table[label_column], table[metric] * 100)
    ax.set_ylabel(metric.replace("_", " ").title() + " (%)")
    ax.set_ylim(0, 100)
    ax.tick_params(axis="x", rotation=25)
    fig.tight_layout()
    if save_path:
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=160, bbox_inches="tight")
    plt.show()
    # Do not return fig: a notebook would display that returned figure again.
    plt.close(fig)


def summarize_shifts(table):
    """Mean and SD across repeated target-training runs; keep tasks separate."""
    trained = table[table["method"].isin(["full", "freeze_1", "freeze_2", "retrain_head", "no_transfer"])]
    return trained.groupby(["condition", "method", "target_classes"], as_index=False).agg(
        mean_balanced_accuracy=("test_balanced_accuracy", "mean"),
        sd_balanced_accuracy=("test_balanced_accuracy", "std"),
        mean_accuracy=("test_accuracy", "mean"),
        sd_accuracy=("test_accuracy", "std"),
        mean_train_accuracy=("train_accuracy", "mean"),
        runs=("test_accuracy", "size"))


def plot_shifts(table, save_path=None, source_baselines=None):
    """Show the two target tasks; original images are a source-only reference.

    Bars show mean target test balanced accuracy, with SD across repeated runs.
    The covariate panel also shows the source model before target training.
    A source model with no Green output has no semantic baseline score.
    """
    summary = summarize_shifts(table)
    if source_baselines is None:
        # Accept earlier result files that include source_only rows.
        source_baselines = table[table["method"] == "source_only"]
    conditions = ["covariate", "semantic"]
    methods = ["full", "freeze_1", "freeze_2", "retrain_head", "no_transfer"]
    labels = ["Full tuning", "Freeze 1", "Freeze 2", "Retrain head", "No transfer"]
    fig, axes = plt.subplots(1, 2, figsize=(13, 4.5), sharey=True)
    for ax, condition, title in zip(axes, conditions, ["Covariate shift", "Semantic shift"]):
        group = summary[summary["condition"] == condition].set_index("method").reindex(methods)
        values = group["mean_balanced_accuracy"] * 100
        errors = group["sd_balanced_accuracy"] * 100
        ax.bar(labels, values, yerr=errors, capsize=4, color=["#2878b5", "#4c9ed9", "#8cc4dd", "#55a868", "#e6a044"])
        ax.set(title=title, ylim=(0, 105), ylabel="Target test balanced accuracy (%)")
        ax.tick_params(axis="x", rotation=15)
        before = source_baselines[source_baselines["condition"] == condition]
        score = None if before.empty else before.iloc[0]["test_balanced_accuracy"]
        if pd.notna(score):
            ax.axhline(float(score) * 100, color="#b33b3b", linestyle="--",
                       label="Source before target training")
            ax.legend(loc="lower left", fontsize=8)
        else:
            ax.text(0.5, 0.97, "Source before training: N/A (new class)",
                    transform=ax.transAxes, ha="center", va="top", fontsize=8)
    fig.tight_layout()
    if save_path:
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=160, bbox_inches="tight")
    plt.show()
    # Do not return fig: a notebook would display that returned figure again.
    plt.close(fig)


def summarize_sizes(table):
    # Combine the repeated seeds for each method/size: mean plus sample SD.
    return table.groupby(["method", "n_per_class"], as_index=False).agg(
        mean_balanced_accuracy=("test_balanced_accuracy", "mean"),
        sd_balanced_accuracy=("test_balanced_accuracy", "std"),
        mean_accuracy=("test_accuracy", "mean"), sd_accuracy=("test_accuracy", "std"),
        runs=("test_accuracy", "size"))


def plot_sample_sizes(table, save_path=None):
    summary = summarize_sizes(table)
    fig, ax = plt.subplots(figsize=(7, 4))
    for method, group in summary.groupby("method", sort=False):
        # Stored accuracy is 0..1; multiply by 100 for percentage axes/error bars.
        # The bars show variation across seeds, not a confidence interval.
        ax.errorbar(group.n_per_class, group.mean_balanced_accuracy * 100,
                    yerr=group.sd_balanced_accuracy * 100,
                    marker="o", capsize=4, label=method)
    ax.set(xlabel="Target training images per class", ylabel="Target test balanced accuracy (%)",
           ylim=(0, 100))
    ax.set_xticks(sorted(table.n_per_class.unique()))
    ax.legend()
    fig.tight_layout()
    if save_path:
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=160, bbox_inches="tight")
    plt.show()
    # Do not return fig: a notebook would display that returned figure again.
    plt.close(fig)


def plot_confusion(result, class_names, save_path=None):
    matrix = np.array(result["confusion"])
    fig, ax = plt.subplots(figsize=(5, 4))
    ax.imshow(matrix, cmap="Blues")
    for row in range(len(class_names)):
        for col in range(len(class_names)):
            ax.text(col, row, str(matrix[row, col]), ha="center", va="center")
    ax.set(xticks=range(len(class_names)), yticks=range(len(class_names)),
           xticklabels=class_names, yticklabels=class_names,
           xlabel="Predicted class", ylabel="True class")
    plt.setp(ax.get_xticklabels(), rotation=30, ha="right")
    fig.tight_layout()
    if save_path:
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=160, bbox_inches="tight")
    plt.show()
    # Do not return fig: a notebook would display that returned figure again.
    plt.close(fig)


def prediction_table(result, records, class_names):
    """Use only with shuffle=False so predictions match file order."""
    if len(records) != result["n"]:
        raise ValueError("Prediction count and record count differ.")
    return pd.DataFrame({"path": [r["path"] for r in records],
                         "true_class": [class_names[i] for i in result["true"]],
                         "predicted_class": [class_names[i] for i in result["predicted"]],
                         "confidence": result["confidence"]})
